package client;


public class ClientApplication {
    /**
     * Client application entry point.
     *
     * @param args - not used
     */
    public static void main(String[] args) {
        new Client().run();
    }
}
