package apiclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.List;

import data.Article;

/**
 * Shows the received articles in the console.
 * First show the top 10 and allow user to navigate through the rest
 */
public class Main {
    private static final int TOP_N = 10;

    public static void main(String[] args) throws IOException {
        List<Article> articlesList = new WikimediaPageViewsClient().getTopPages(LocalDate.of(2017, 07, 13));
        for (int i = 0; i < TOP_N; i++) {
            System.out.println(articlesList.get(i));
            System.out.println();
        }
        boolean running = true;
        int current = TOP_N;
        while (running) {
            System.out.println("\t(n) Next\t(q) Quit ");
            BufferedReader buReader = new BufferedReader(new InputStreamReader(System.in));
            String eingabe = buReader.readLine();
            if (eingabe.startsWith("n")) {
                System.out.println(articlesList.get(current));
                current += 1;
            } else if (eingabe.startsWith("q"))
                running = false;
        }

    }

}
